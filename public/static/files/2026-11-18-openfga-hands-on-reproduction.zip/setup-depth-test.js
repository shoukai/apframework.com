const api = process.env.FGA_API_URL || 'http://127.0.0.1:18080';
const depths = (process.env.DEPTHS || '1,5,10').split(',').map(Number);

const direct = (type) => ({ directly_related_user_types: [{ type }] });
const computedFromParent = {
  union: {
    child: [
      { this: {} },
      { tupleToUserset: {
        tupleset: { object: '', relation: 'parent' },
        computedUserset: { object: '', relation: 'viewer' },
      } },
    ],
  },
};
const model = {
  schema_version: '1.1',
  type_definitions: [
    { type: 'user' },
    {
      type: 'folder',
      relations: { parent: { this: {} }, viewer: computedFromParent },
      metadata: { relations: { parent: direct('folder'), viewer: direct('user') } },
    },
    {
      type: 'document',
      relations: { parent: { this: {} }, viewer: computedFromParent },
      metadata: { relations: { parent: direct('folder'), viewer: direct('user') } },
    },
  ],
};

async function post(path, body) {
  const response = await fetch(`${api}${path}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(`${path} returned ${response.status}: ${JSON.stringify(result)}`);
  return result;
}

async function main() {
  if (depths.some((depth) => !Number.isInteger(depth) || depth < 1 || depth > 24)) {
    throw new Error('Depths must be integers from 1 to 24.');
  }
  const store = await post('/stores', { name: 'openfga-hands-on-depth' });
  const writtenModel = await post(`/stores/${store.id}/authorization-models`, model);
  const tuples = [{ user: 'user:alice', relation: 'viewer', object: 'folder:root' }];
  const targets = {};
  for (const depth of depths) {
    let parent = 'folder:root';
    for (let level = 1; level < depth; level++) {
      const current = `folder:d${depth}-level${level}`;
      tuples.push({ user: parent, relation: 'parent', object: current });
      parent = current;
    }
    const document = `document:depth-${depth}`;
    tuples.push({ user: parent, relation: 'parent', object: document });
    targets[depth] = document;
  }
  await post(`/stores/${store.id}/write`, {
    authorization_model_id: writtenModel.authorization_model_id,
    writes: { tuple_keys: tuples },
  });
  console.log(JSON.stringify({
    api,
    storeId: store.id,
    modelId: writtenModel.authorization_model_id,
    depths,
    targets,
    tuplesWritten: tuples.length,
  }));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
