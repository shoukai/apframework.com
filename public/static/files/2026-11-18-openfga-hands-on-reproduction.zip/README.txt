OpenFGA hands-on reproduction materials

Contents
- model.fga, model-v2.fga, model-depth.fga: authorization models used in the article
- store.fga.yaml, tuples.yaml: model tests and sample relationship tuples
- http-benchmark.js: Node.js HTTP benchmark client
- seed-members.js: add synthetic organization membership tuples
- setup-depth-test.js: create the inheritance-depth fixture through the OpenFGA HTTP API
- verification-log.md: environment, commands, observed outputs, measurements, and limitations

Basic model test
1. Start Docker Desktop.
2. From this directory, run:
   docker run --rm --network host -v "$PWD:/work" -w /work openfga/cli model test --tests store.fga.yaml

HTTP benchmark
Run OpenFGA v1.22.1 with a Store and model containing the expected fixture. Set FGA_STORE_ID and FGA_MODEL_ID, then run:
   node http-benchmark.js
Optional variables include FGA_API_URL, REQUESTS, WARMUP, CONCURRENCY, CONSISTENCY, METHOD, RELATION, OBJECT, OBJECT_TYPE, and USER_ID. See the script for defaults and supported values.

The article's Store IDs and benchmark outputs document a completed in-memory test run; they are not a persistent hosted service. Recreate the Store, model, and tuples before rerunning API experiments. The recorded measurements are single-run observations from one local ARM64 Docker setup, not production capacity guarantees.
