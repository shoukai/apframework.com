const http = require('node:http');
const os = require('node:os');
const { performance } = require('node:perf_hooks');

const api = process.env.FGA_API_URL || 'http://127.0.0.1:18080';
const storeId = process.env.FGA_STORE_ID;
const modelId = process.env.FGA_MODEL_ID;
const concurrency = Number(process.env.CONCURRENCY || 1);
const requests = Number(process.env.REQUESTS || 2000);
const relation = process.env.RELATION || 'editor';
const object = process.env.OBJECT || 'document:roadmap';
const user = process.env.USER_ID || 'user:alice';
const consistency = process.env.CONSISTENCY || 'HIGHER_CONSISTENCY';
const method = process.env.METHOD || 'check';
const type = process.env.OBJECT_TYPE || 'document';

if (!storeId || !modelId || !Number.isInteger(concurrency) || concurrency < 1 || !Number.isInteger(requests) || requests < 1) {
  throw new Error('Set FGA_STORE_ID, FGA_MODEL_ID, and positive integer CONCURRENCY/REQUESTS.');
}

const endpoint = method === 'list-objects' ? 'list-objects' : 'check';
const requestBody = method === 'list-objects'
  ? { user, relation, type, authorization_model_id: modelId, consistency }
  : { tuple_key: { user, relation, object }, authorization_model_id: modelId, consistency };
const payload = Buffer.from(JSON.stringify(requestBody));
const latencies = new Float64Array(requests);
let next = 0;
let errors = 0;
let denied = 0;

function check() {
  return new Promise((resolve) => {
    const started = performance.now();
    const req = http.request(`${api}/stores/${storeId}/${endpoint}`, {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'content-length': payload.length,
        connection: 'keep-alive',
      },
    }, (res) => {
      const chunks = [];
      res.on('data', (chunk) => chunks.push(chunk));
      res.on('end', () => {
        const elapsed = performance.now() - started;
        try {
          const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          if (res.statusCode !== 200) errors++;
          else if (method === 'list-objects') {
            if (!Array.isArray(body.objects)) errors++;
            else if (!body.objects.includes(object)) denied++;
          } else if (typeof body.allowed !== 'boolean') errors++;
          else if (!body.allowed) denied++;
        } catch {
          errors++;
        }
        resolve(elapsed);
      });
    });
    req.on('error', () => {
      errors++;
      resolve(performance.now() - started);
    });
    req.end(payload);
  });
}

async function worker() {
  while (true) {
    const index = next++;
    if (index >= requests) return;
    latencies[index] = await check();
  }
}

async function main() {
  const warmup = Number(process.env.WARMUP || 200);
  await Promise.all(Array.from({ length: Math.min(concurrency, warmup) }, async (_, workerIndex) => {
    for (let index = workerIndex; index < warmup; index += concurrency) await check();
  }));
  const wallStarted = performance.now();
  await Promise.all(Array.from({ length: concurrency }, worker));
  const actualWallMs = performance.now() - wallStarted;
  const values = Array.from(latencies).sort((a, b) => a - b);
  const percentile = (p) => values[Math.min(values.length - 1, Math.ceil(values.length * p) - 1)];
  const elapsed = values.reduce((sum, value) => sum + value, 0);
  console.log(JSON.stringify({
    api,
    storeId,
    modelId,
    method,
    user,
    relation,
    object,
    consistency,
    requests,
    warmup,
    concurrency,
    errors,
    denied,
    latencyMs: {
      min: Number(values[0].toFixed(3)),
      mean: Number((elapsed / values.length).toFixed(3)),
      p50: Number(percentile(0.50).toFixed(3)),
      p95: Number(percentile(0.95).toFixed(3)),
      p99: Number(percentile(0.99).toFixed(3)),
      max: Number(values.at(-1).toFixed(3)),
    },
    clientMeasuredWallMs: Number(actualWallMs.toFixed(3)),
    clientMeasuredRequestRate: Number((requests / (actualWallMs / 1000)).toFixed(2)),
    host: { platform: process.platform, arch: process.arch, cpusVisible: os.availableParallelism() },
  }));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
