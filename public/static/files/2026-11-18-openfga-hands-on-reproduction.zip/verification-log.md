# Verification Log

## 2026-11-17: functional and HTTP checks

- Host: Apple Silicon macOS, Darwin 25.6.0, arm64; host reports 18 logical CPUs and 64 GiB physical RAM.
- Docker Desktop engine: 29.9.3; Docker VM reports 8 vCPU and 20,940,308,480 bytes RAM.
- OpenFGA image: `openfga/openfga:v1.22.1`, platform `linux/arm64`, image ID `sha256:b852071314f1fda1194d341a6ebac0a4f619b3cd87a6626d2ccc7048af4ec671`, repo digest `openfga/openfga@sha256:b852071314f1fda1194d341a6ebac0a4f619b3cd87a6626d2ccc7048af4ec671`. Server reports `v1.22.1`, commit `44054f542f64e9b9589dd26a595081b3d2cfd942`, build date `2026-10-28T12:53:36Z`.
- Container: in-memory datastore; `--cpus=4 --memory=8g`; HTTP exposed only on host loopback as `127.0.0.1:18080`; playground disabled; unauthenticated local-only test. Health endpoint returned `{"status":"SERVING"}`.
- CLI image: `openfga/cli:latest`, `fga version v0.9.0`, commit `4b10e119c40a02dac0a665c9f8516b2ea3a36291`, date `2026-11-12T14:47:14Z`.
- CLI note: `fga store create` requires `--name`; a positional name produced `Error: required flag(s) "name" not set`. After correction the Store was created successfully.
- Store file: `examples/store.fga.yaml`; model test command: `docker run --rm --network host -v <examples>:/work -w /work openfga/cli model test --tests store.fga.yaml`.
- Initial model-test output before adding a pre-start conditional denial: `Tests 2/2 passing`, `Checks 8/8 passing`, `ListObjects 2/2 passing`. Final rerun after adding the assertion: `Tests 2/2 passing`, `Checks 9/9 passing`, `ListObjects 2/2 passing`.
- Service Store ID: `01M7MWY9490VXBB1W7MVC7P0Y0`; model v1 ID: `01M7MX3RYNCKCBYYDPS73B6C75`; model v2 ID: `01M7MXGNVC0HZJ799CH1M3G55N`.
- API results with model v1: Alice inherited editor Check => `{"allowed":true,"resolution":""}`; Bob direct editor Check => allowed true; Mallory editor Check => allowed false; ListObjects for Alice => `{"objects":["document:roadmap"]}`.
- Conditional Check via HTTP: with tuple grant `2026-11-17T12:00:00Z` + `2h`, Carol at `2026-11-17T13:00:00Z` => `allowed:true`; at `2026-11-17T15:00:00Z` => `allowed:false`. The original model expression only bounded the end of the grant window. During final review, tightened it to `current_time >= grant_time && current_time < grant_time + grant_duration` and added a pre-start denial at `2026-11-17T11:00:00Z`. Wrote the corrected model to the live Store as model `01M7N0E6VVR28D492CENZQNXQX` and reran the REST Check at all three points: 11:00Z `allowed:false`, 13:00Z `allowed:true`, and 15:00Z `allowed:false`; the updated CLI model test also passed all 3 conditional assertions.
- Revocation: deleting Bob's `editor` tuple returned `{}`; Bob Check became false; Alice's inherited editor Check remained true.
- Model switch: wrote model v2 removing `organization#member` from `project#editor`. Explicit v1 Check for Alice remained true; explicit v2 Check returned false; omitted model ID returned false and server log reported latest model ID v2.
- The CLI image was invoked with `--rm`. During attempts to create another Store, two CLI containers exited with code 137/SIGTERM, while the OpenFGA service health remained `SERVING`. Depth fixture was therefore set up through the verified REST API instead. No attribution of that CLI failure to OpenFGA is made.

## 2026-11-17: HTTP benchmark method

- Script: `examples/http-benchmark.js` (Node.js `http`, host runtime v22.22.2, macOS arm64; 18 visible CPUs).
- The script performs sequential requests per worker with HTTP keep-alive. Warm-up requests are discarded; measured per-request latency covers Node client wall time including HTTP request/response handling through the local Docker port. It is not server-only latency.
- For every data point, payload was constant, `authorization_model_id` explicit, and consistency `HIGHER_CONSISTENCY` unless noted. The consistency preference bypasses relevant query caches; server was configured with Check caches disabled by default. Each functional query expected allow/target in ListObjects; errors and unexpected denies are counted.
- Baseline 2,000 requests / warmup 200 / concurrency 1 / Check: errors 0, denied 0; min 0.340 ms, mean 0.442, p50 0.421, p95 0.590, p99 0.845, max 1.803; wall 905.491 ms; completed-request rate 2,208.75/s.
- 4,000 requests / warmup 200 / concurrency 16 / Check / HIGHER_CONSISTENCY: errors 0, denied 0; min 0.356 ms, mean 1.133, p50 0.965, p95 2.320, p99 3.113, max 4.375; wall 285.236 ms; 14,023.48/s.
- 4,000 requests / warmup 200 / concurrency 32 / Check / HIGHER_CONSISTENCY: errors 0, denied 0; min 0.493 ms, mean 1.928, p50 1.684, p95 3.559, p99 4.385, max 5.225; wall 242.419 ms; 16,500.35/s.
- 4,000 requests / warmup 200 / concurrency 16 / Check / MINIMIZE_LATENCY: errors 0, denied 0; min 0.386 ms, mean 1.128, p50 0.983, p95 2.266, p99 2.938, max 3.594; wall 283.959 ms; 14,086.54/s. This is only one run per setting; no statistically meaningful consistency-mode conclusion.
- Relationship-scale dataset: after Bob's direct tuple was deleted, the baseline contains four tuples (Alice member, Acme userset editor of Launch, Launch parent of Roadmap, and Carol conditional timed_viewer). Adding 999 unrelated membership tuples gives 1,003 tuples total; Check concurrency 16 / 2,000 requests / warmup 100: errors 0, denied 0; p50 1.019 ms, p95 2.307, p99 2.778; wall 147.350 ms; 13,573.11/s.
- Relationship-scale dataset: add 9,000 more unrelated Acme member tuples, 10,003 tuples total; same Check settings: errors 0, denied 0; p50 1.437 ms, p95 2.854, p99 3.833; wall 199.545 ms; 10,022.81/s. The live Store read enumerated 10,003 tuples: 10,000 `organization:acme#member` tuples (Alice plus 9,999 seeded subjects), and one each for project editor, document project, and conditional timed_viewer. The Alice membership tuple remains on the authorization path; added tuples belong to different subjects. This is a small synthetic one-run observation, not a general scaling curve.
- Depth Store ID `01M7MYCHRAVS20QS0ZNB47GFP0`; model ID `01M7MYCHRFD2JHYV7CPR4ERNN2`. Each store fixture contains 1 root Alice viewer tuple and branch-specific parent tuples for depths 1, 5, and 10 (17 total tuples). Actual path depths 1/5/10 are measured via Check at concurrency 16 / 2,000 requests / warmup 100: depth 1 p50 0.980 ms, p95 1.826, p99 2.460; depth 5 p50 1.094, p95 2.333, p99 3.155; depth 10 p50 1.102, p95 2.483, p99 3.069. All errors 0, denied 0. One run each; not a performance law.
- Check vs ListObjects paired run: same depth-10 Store/model, same subject/relation/object type, `HIGHER_CONSISTENCY`, concurrency 4, 1,000 measured requests, warmup 50. Check: p50 0.590, p95 0.945, p99 1.141 ms; rate 6,276/s. ListObjects: p50 0.583, p95 1.067, p99 1.530 ms; rate 6,065/s. Both errors 0 and returned/confirmed the target document. This compares only a one-result fixture and equal request counts; not equivalent workloads generally.
- Container resources: before benchmarks `docker stats` showed 22.61 MiB / 8 GiB; after feature and load tests, one no-stream sample showed 52.48 MiB / 8 GiB, CPU 0.04%, 11 PIDs. These are snapshots, not peak or per-run utilization. Host CPU attribution and benchmark-interval peak memory were not collected. Metrics port 2112 was not mapped to the host.
- Final data-store is in-memory and ephemeral. No PostgreSQL/MySQL comparison, persistent storage, multi-replica deployment, TLS/authentication overhead, remote network, dataset-size matrix beyond one membership-key scale, repeated statistical runs, confidence interval, independent load generator, CPU profile or peak-resource measurement.

## Reproduction files

- `examples/model.fga`, `examples/model-v2.fga`, `examples/model-depth.fga`
- `examples/store.fga.yaml`, `examples/tuples.yaml`
- `examples/http-benchmark.js`, `examples/seed-members.js`, `examples/setup-depth-test.js`
