const { performance } = require('node:perf_hooks');

const api = process.env.FGA_API_URL || 'http://127.0.0.1:18080';
const storeId = process.env.FGA_STORE_ID;
const modelId = process.env.FGA_MODEL_ID;
const count = Number(process.env.MEMBERS || 0);
const batchSize = Number(process.env.BATCH_SIZE || 100);
const offset = Number(process.env.OFFSET || 0);

if (!storeId || !modelId || !Number.isInteger(count) || count < 0 || !Number.isInteger(batchSize) || batchSize < 1) {
  throw new Error('Set FGA_STORE_ID, FGA_MODEL_ID, and valid MEMBERS/BATCH_SIZE values.');
}

async function main() {
  const started = performance.now();
  let written = 0;
  for (let start = 0; start < count; start += batchSize) {
    const tupleKeys = Array.from({ length: Math.min(batchSize, count - start) }, (_, index) => ({
      user: `user:member-${offset + start + index}`,
      relation: 'member',
      object: 'organization:acme',
    }));
    const response = await fetch(`${api}/stores/${storeId}/write`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({
        authorization_model_id: modelId,
        writes: { tuple_keys: tupleKeys, on_duplicate: 'ignore' },
      }),
    });
    const body = await response.json();
    if (!response.ok) throw new Error(`Write failed (${response.status}): ${JSON.stringify(body)}`);
    written += tupleKeys.length;
  }
  console.log(JSON.stringify({ count: written, batchSize, offset, elapsedMs: Number((performance.now() - started).toFixed(3)) }));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
